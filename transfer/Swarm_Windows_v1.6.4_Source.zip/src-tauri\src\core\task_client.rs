use crate::core::result_signing;
use reqwest::Url;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::env;

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct StreamingContract {
    #[serde(default)]
    pub version: Option<String>,

    #[serde(default)]
    pub requested_mode: Option<String>,

    #[serde(default)]
    pub effective_mode: Option<String>,

    #[serde(default)]
    pub transport: Option<String>,

    #[serde(default)]
    pub raw_chunks_persisted: Option<bool>,
}


#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AdaptiveExecutionContract {
    #[serde(default)]
    pub version: Option<String>,

    #[serde(default)]
    pub output_token_budget: Option<u64>,

    #[serde(default)]
    pub execution_budget_ms: Option<u64>,

    #[serde(default)]
    pub inactivity_budget_ms: Option<u64>,

    #[serde(default)]
    pub absolute_ceiling_ms: Option<u64>,

    #[serde(default)]
    pub progress_reporting: Option<bool>,

    #[serde(default)]
    pub structured_failure_telemetry: Option<bool>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NodeWebSearchContractV1 {
    #[serde(default)]
    pub broker_path: Option<String>,

    #[serde(default)]
    pub max_searches: Option<u64>,

    #[serde(default)]
    pub max_results_per_search: Option<u64>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NodeWebFetchContractV1 {
    #[serde(default)]
    pub max_fetches: Option<u64>,

    #[serde(default)]
    pub max_bytes_per_fetch: Option<u64>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NodeInitialSearchResultV1 {
    #[serde(default)]
    pub id: Option<u64>,

    #[serde(default)]
    pub rank: Option<u64>,

    #[serde(default)]
    pub title: String,

    pub url: String,

    #[serde(default)]
    pub domain: String,

    #[serde(default)]
    pub description: String,

    #[serde(default)]
    pub published_at: Option<String>,

    #[serde(default)]
    pub retrieved_at: Option<String>,

    #[serde(default)]
    pub provider: String,

    pub broker_ticket: String,
    pub ticket_expires_at: u64,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NodeInitialSearchV1 {
    #[serde(default)]
    pub version: Option<String>,

    #[serde(default)]
    pub provider: String,

    #[serde(default)]
    pub query: String,

    #[serde(default)]
    pub results: Vec<NodeInitialSearchResultV1>,

    #[serde(default)]
    pub result_count: u64,

    #[serde(default)]
    pub cache_hit: bool,

    #[serde(default)]
    pub provider_elapsed_ms: u64,

    #[serde(default)]
    pub broker_elapsed_ms: u64,

    #[serde(default)]
    pub ticket_expires_at: Option<u64>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NodeToolContractV1 {
    #[serde(default)]
    pub version: Option<String>,

    #[serde(default)]
    pub stage: Option<String>,

    #[serde(default)]
    pub initial_query: Option<String>,

    #[serde(default)]
    pub initial_search: Option<NodeInitialSearchV1>,

    #[serde(default)]
    pub required_capabilities: Vec<String>,

    #[serde(default)]
    pub allowed_tools: Vec<String>,

    #[serde(default)]
    pub web_search: Option<NodeWebSearchContractV1>,

    #[serde(default)]
    pub web_fetch: Option<NodeWebFetchContractV1>,

    #[serde(default)]
    pub max_tool_steps: Option<u64>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TaskEnvelope {
    pub task_id: Value,

    #[serde(default)]
    pub attempt_id: Option<String>,

    #[serde(default)]
    pub client_name: Option<String>,

    #[serde(default)]
    pub prompt: String,

    #[serde(default)]
    pub required_model: Option<String>,

    #[serde(default)]
    pub selected_model: Option<String>,

    #[serde(default)]
    pub company_model: Option<crate::core::company_model::CompanyModelExecutionContractV1>,

    #[serde(default)]
    pub model_route_reason: Option<String>,

    #[serde(default)]
    pub model_routing_version: Option<String>,

    #[serde(default)]
    pub verification_seed: Option<Value>,

    #[serde(default)]
    pub checkpoint_indices: Vec<Value>,

    #[serde(default)]
    pub verification_method: Option<String>,

    #[serde(default)]
    pub max_output_tokens: Option<u64>,
    // ADAPTIVE_EXECUTION_CONTRACT_V1
    #[serde(default)]
    pub execution_contract: Option<AdaptiveExecutionContract>,


    #[serde(default)]
    pub streaming_contract: Option<StreamingContract>,

    #[serde(default)]
    pub tool_contract: Option<NodeToolContractV1>,
}

impl TaskEnvelope {
    pub fn task_id_text(&self) -> String {
        match &self.task_id {
            Value::String(value) => value.clone(),
            value => value.to_string(),
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetJobsResponse {
    #[serde(default)]
    pub task: Option<TaskEnvelope>,

    #[serde(default)]
    pub tasks: Vec<TaskEnvelope>,

    #[serde(default)]
    pub blocked: bool,

    #[serde(default)]
    pub block_reason: Option<String>,

    #[serde(default)]
    pub message: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ResultPayload {
    pub task_id: Value,

    #[serde(skip_serializing_if = "Option::is_none")]
    pub attempt_id: Option<String>,
    pub worker: String,
    pub provider_email: String,
    pub score: u16,
    pub signature: String,
    pub hardware_id: String,
    pub ai_output: String,
    pub ai_translation: Option<String>,
    pub status: String,

    #[serde(rename = "latency_ms")]
    pub latency_ms: u64,

    pub required_model: String,
    pub model_id_used: String,
    pub runtime: String,
    pub runtime_acceleration: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SubmitResultEnvelope {
    pub file_hash: String,
    pub payload: ResultPayload,
}

pub struct TaskClientDryRun {
    pub poll_endpoint_valid: bool,
    pub submit_endpoint_valid: bool,
    pub hardware_id_present: bool,
    pub provider_email_present: bool,
    pub capability_count: usize,
    pub limit: u16,
    pub network_request_sent: bool,
}

pub fn build_poll_url(
    hardware_id: &str,
    provider_email: &str,
    capabilities: &[String],
    version: &str,
    platform: &str,
) -> Result<Url, String> {
    build_poll_url_with_limit(
        hardware_id,
        provider_email,
        capabilities,
        version,
        platform,
        1,
    )
}

pub fn build_poll_url_with_limit(
    hardware_id: &str,
    provider_email: &str,
    capabilities: &[String],
    version: &str,
    platform: &str,
    limit: u16,
) -> Result<Url, String> {
    let base = env::var("GCP_BASE_URL")
        .unwrap_or_else(|_| "https://api.edgeswarm.io".into())
        .trim_end_matches('/')
        .to_string();

    let mut url = Url::parse(&format!("{base}/swarm/get-jobs"))
        .map_err(|_| "get_jobs_url_invalid".to_string())?;

    let limit = limit.clamp(1, 10).to_string();

    url.query_pairs_mut()
        .append_pair("hardwareId", hardware_id)
        .append_pair("providerEmail", provider_email)
        .append_pair("capabilities", &capabilities.join(","))
        .append_pair("limit", &limit)
        .append_pair("version", version)
        .append_pair("appType", "cross-platform-node")
        .append_pair("platform", platform);

    Ok(url)
}

pub fn build_submit_result(
    task: &TaskEnvelope,
    ai_output: &str,
    provider_email: &str,
    worker: &str,
    hardware_id: &str,
    private_key: &str,
    latency_ms: u64,
    model_id_used: &str,
    runtime: &str,
    runtime_acceleration: &str,
) -> Result<SubmitResultEnvelope, String> {
    let file_hash = Sha256::digest(ai_output.as_bytes())
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect::<String>();

    let score = 100;
    let task_id = task.task_id_text();

    let signature =
        result_signing::sign_result_with_attempt(&task_id, score, &file_hash, hardware_id, task.attempt_id.as_deref(), private_key)?;

    Ok(SubmitResultEnvelope {
        file_hash,
        payload: ResultPayload {
            task_id: task.task_id.clone(),
            attempt_id: task.attempt_id.clone(),
            worker: worker.to_string(),
            provider_email: provider_email.to_lowercase(),
            score,
            signature,
            hardware_id: hardware_id.to_string(),
            ai_output: ai_output.to_string(),
            ai_translation: None,
            status: "success".into(),
            latency_ms,
            required_model: task.required_model.clone().unwrap_or_default(),
            model_id_used: model_id_used.to_string(),
            runtime: runtime.to_string(),
            runtime_acceleration: runtime_acceleration.to_string(),
        },
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_production_task_envelope() {
        let parsed: GetJobsResponse = serde_json::from_str(
            r#"{
                    "task":{
                        "taskId":2001,
                        "prompt":"Say hello",
                        "requiredModel":"Neural-Inference-3B",
                        "selectedModel":"qwen2.5:3b",
                        "maxOutputTokens":128
                    },
                    "tasks":[{
                        "taskId":2001,
                        "prompt":"Say hello",
                        "requiredModel":"Neural-Inference-3B",
                        "selectedModel":"qwen2.5:3b",
                        "maxOutputTokens":128
                    }]
                }"#,
        )
        .unwrap();

        assert_eq!(parsed.tasks.len(), 1);
        assert_eq!(parsed.tasks[0].task_id_text(), "2001");
    }

    #[test]
    fn builds_signed_result_envelope() {
        let task = TaskEnvelope {
            attempt_id: None,
            company_model: None,
            task_id: Value::from(2001),
            client_name: None,
            prompt: "Say hello".into(),
            required_model: Some("Neural-Inference-3B".into()),
            selected_model: Some("qwen2.5:3b".into()),
            model_route_reason: None,
            model_routing_version: None,
            verification_seed: None,
            checkpoint_indices: vec![],
            verification_method: None,
            max_output_tokens: Some(128),
            execution_contract: None,
            streaming_contract: None,
            tool_contract: None,
        };

        let result = build_submit_result(
            &task,
            r#"{"response":"hello"}"#,
            "test@example.com",
            "0x7E5F4552091A69125d5DfCb7b8C2659029395Bdf",
            "6957eb286fb15a2813ce44699232d053d69d91be307fdf0018df1001b4eda5de",
            "0000000000000000000000000000000000000000000000000000000000000001",
            100,
            "qwen2.5:3b",
            "llama.cpp",
            "cpu",
        )
        .unwrap();

        assert_eq!(result.file_hash.len(), 64);
        assert_eq!(result.payload.signature.len(), 132);
        assert_eq!(result.payload.score, 100);
    }
}
