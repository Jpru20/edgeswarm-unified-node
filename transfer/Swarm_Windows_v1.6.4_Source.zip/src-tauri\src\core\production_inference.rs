use crate::core::generation_policy::{
    production_generation_settings_adaptive_v1,
    production_generation_settings_v1,
};
use reqwest::blocking::Client;
use serde_json::{json, Value};
use std::io::{BufRead, BufReader};
use std::time::{Duration, Instant};

#[derive(Debug)]
pub struct ProductionInferenceResult {
    pub ai_output: String,
    pub latency_ms: u64,
    pub input_tokens: u64,
    pub output_tokens: u64,
    pub tokens_per_second: f64,
    pub prompt_eval_ms: Option<u64>,
    pub generation_ms: Option<u64>,
    pub max_tokens: u32,
}

#[derive(Clone)]
pub struct ProductionLlamaClient {
    http: Client,
    base_url: String,
}

// ADAPTIVE_INFERENCE_TIMEOUT_V1
const LEGACY_INFERENCE_TIMEOUT_MS_V1: u64 = 105_000;

const ADAPTIVE_DEFAULT_ABSOLUTE_CEILING_MS_V1: u64 =
    900_000;

fn inference_request_timeout_v1(
    adaptive_execution: bool,
    absolute_ceiling_ms: Option<u64>,
) -> Duration {
    let timeout_ms =
        if adaptive_execution {
            absolute_ceiling_ms
                .unwrap_or(
                    ADAPTIVE_DEFAULT_ABSOLUTE_CEILING_MS_V1
                )
                .max(1)
        } else {
            LEGACY_INFERENCE_TIMEOUT_MS_V1
        };

    Duration::from_millis(timeout_ms)
}

impl ProductionLlamaClient {
    pub fn new(base_url: impl Into<String>) -> Result<Self, String> {
        let http = Client::builder()
            .connect_timeout(Duration::from_secs(20))
            .no_proxy()
            .build()
            .map_err(|_| "production_llama_client_build_failed".to_string())?;

        Ok(Self {
            http,
            base_url: base_url.into().trim_end_matches('/').to_string(),
        })
    }

    pub fn health_check(&self) -> Result<(), String> {
        let response = self
            .http
            .get(format!("{}/health", self.base_url))
            .timeout(Duration::from_secs(20))
            .send()
            .map_err(|_| "production_llama_health_request_failed".to_string())?;

        if !response.status().is_success() {
            return Err(format!(
                "production_llama_not_ready_http_{}",
                response.status().as_u16()
            ));
        }

        Ok(())
    }

    // TRUE_NODE_CHUNK_STREAMING_V1
    // Reads llama.cpp OpenAI-compatible SSE deltas while preserving
    // the same complete final result used by normal consensus.
    pub fn execute_streaming<F>(
        &self,
        prompt: &str,
        max_output_tokens: Option<u64>,
        on_chunk: F,
    ) -> Result<ProductionInferenceResult, String>
    where
        F: FnMut(&str),
    {
        self.execute_streaming_with_policy(
            prompt,
            max_output_tokens,
            false,
            None,
            on_chunk,
        )
    }

    pub fn execute_streaming_adaptive<F>(
        &self,
        prompt: &str,
        max_output_tokens: Option<u64>,
        absolute_ceiling_ms: Option<u64>,
        on_chunk: F,
    ) -> Result<ProductionInferenceResult, String>
    where
        F: FnMut(&str),
    {
        self.execute_streaming_with_policy(
            prompt,
            max_output_tokens,
            true,
            absolute_ceiling_ms,
            on_chunk,
        )
    }

    fn execute_streaming_with_policy<F>(
        &self,
        prompt: &str,
        max_output_tokens: Option<u64>,
        adaptive_execution: bool,
        absolute_ceiling_ms: Option<u64>,
        mut on_chunk: F,
    ) -> Result<ProductionInferenceResult, String>
    where
        F: FnMut(&str),
    {
        let prompt = prompt.trim();

        if prompt.is_empty() {
            return Err("production_task_prompt_empty".into());
        }
        // ADAPTIVE_GENERATION_BUDGET_V1
        const ADAPTIVE_DEFAULT_OUTPUT_TOKENS_V1: u64 = 4096;

        let requested_u64 =
            max_output_tokens
                .unwrap_or(
                    if adaptive_execution {
                        ADAPTIVE_DEFAULT_OUTPUT_TOKENS_V1
                    } else {
                        512
                    }
                )
                .max(1);

        let requested =
            u32::try_from(requested_u64)
                .unwrap_or(u32::MAX);

        let generation =
            if adaptive_execution {
                production_generation_settings_adaptive_v1(
                    prompt,
                    None,
                    None,
                )
            } else {
                production_generation_settings_v1(
                    prompt,
                    None,
                    Some(requested.min(4096)),
                )
            };

        let request_max_tokens: i64 =
            if adaptive_execution &&
                generation.max_tokens == u32::MAX
            {
                -1
            } else {
                generation.max_tokens
                    .max(1)
                    .min(4096) as i64
            };

        let max_tokens =
            if request_max_tokens < 0 {
                0
            } else {
                request_max_tokens as u32
            };

        println!(
            "INFERENCE_OUTPUT_TOKEN_LIMIT={}",
            if request_max_tokens < 0 {
                "unbounded".to_string()
            } else {
                request_max_tokens.to_string()
            }
        );

        let mut body = json!({
            "model": "local-model",
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": generation.temperature,
            "top_p": generation.top_p,
            "max_tokens": request_max_tokens,
            "stop": generation.stop,
            "stream": true,
            "stream_options": {
                "include_usage": true
            }
        });

        if adaptive_execution && generation.mode == "json" {
            body["json_schema"] = json!({
                "type": "object"
            });
        }

        let started = Instant::now();

        let request_timeout_v1 =
            inference_request_timeout_v1(
                adaptive_execution,
                absolute_ceiling_ms,
            );

        println!(
            "INFERENCE_REQUEST_TIMEOUT_MS={}",
            request_timeout_v1.as_millis()
        );

        let response = self
            .http
            .post(format!(
                "{}/v1/chat/completions",
                self.base_url
            ))
            .header("Authorization", "Bearer no-key")
            .json(&body)
            .timeout(request_timeout_v1)
            .send()
            .map_err(|error| {
                if error.is_timeout() {
                    "production_llama_stream_timeout".to_string()
                } else {
                    "production_llama_stream_request_failed".to_string()
                }
            })?;

        let status = response.status();

        if !status.is_success() {
            let body =
                response
                    .text()
                    .unwrap_or_default()
                    .replace('\r', " ")
                    .replace('\n', " ");

            let body: String =
                body
                    .chars()
                    .take(800)
                    .collect();

            return Err(format!(
                "production_llama_http_{}_body={}",
                status.as_u16(),
                body
            ));
        }let reader = BufReader::new(response);

        let mut output = String::new();

        let mut input_tokens = 0_u64;
        let mut output_tokens = 0_u64;
        let mut runtime_tps = None::<f64>;
        let mut prompt_eval_ms = None::<u64>;
        let mut generation_ms = None::<u64>;

        for line_result in reader.lines() {
            let line =
                line_result.map_err(|_| "production_llama_stream_read_failed".to_string())?;

            let line = line.trim();

            if line.is_empty() || line.starts_with(':') {
                continue;
            }

            let Some(data) = line.strip_prefix("data:") else {
                continue;
            };

            let data = data.trim();

            if data == "[DONE]" {
                break;
            }

            let parsed: Value = serde_json::from_str(data)
                .map_err(|_| "production_llama_stream_json_failed".to_string())?;

            let delta = parsed
                .pointer("/choices/0/delta/content")
                .and_then(Value::as_str)
                .or_else(|| parsed.pointer("/choices/0/text").and_then(Value::as_str))
                .unwrap_or("");

            if !delta.is_empty() {
                output.push_str(delta);
                on_chunk(delta);
            }

            if let Some(value) = parsed
                .pointer("/usage/prompt_tokens")
                .and_then(Value::as_u64)
                .or_else(|| parsed.pointer("/timings/prompt_n").and_then(Value::as_u64))
            {
                input_tokens = value;
            }

            if let Some(value) = parsed
                .pointer("/usage/completion_tokens")
                .and_then(Value::as_u64)
                .or_else(|| {
                    parsed
                        .pointer("/timings/predicted_n")
                        .and_then(Value::as_u64)
                })
            {
                output_tokens = value;
            }

            if let Some(value) = parsed
                .pointer("/timings/predicted_per_second")
                .and_then(Value::as_f64)
            {
                runtime_tps = Some(value);
            }

            if let Some(value) = parsed.pointer("/timings/prompt_ms").and_then(Value::as_f64) {
                prompt_eval_ms = Some(value.round() as u64);
            }

            if let Some(value) = parsed
                .pointer("/timings/predicted_ms")
                .and_then(Value::as_f64)
            {
                generation_ms = Some(value.round() as u64);
            }
        }

        let output = output.trim();

        if output.is_empty() {
            return Err("production_llama_empty_output".into());
        }

        let ai_output = if output.starts_with('{') {
            match serde_json::from_str::<Value>(output) {
                Ok(Value::Object(object)) => serde_json::to_string(&Value::Object(object))
                    .map_err(|_| "production_output_encode_failed".to_string())?,

                _ => json!({
                    "response": output
                })
                .to_string(),
            }
        } else {
            json!({
                "response": output
            })
            .to_string()
        };

        let latency_ms = started.elapsed().as_millis() as u64;

        if output_tokens == 0 {
            output_tokens = ((output.chars().count() as u64) + 3) / 4;
        }

        let tokens_per_second = runtime_tps.unwrap_or_else(|| {
            if latency_ms > 0 {
                output_tokens as f64 / (latency_ms as f64 / 1000.0)
            } else {
                0.0
            }
        });

        Ok(ProductionInferenceResult {
            ai_output,
            latency_ms,
            input_tokens,
            output_tokens,
            tokens_per_second,
            prompt_eval_ms,
            generation_ms,
            max_tokens,
        })
    }

    pub fn execute(
        &self,
        prompt: &str,
        max_output_tokens: Option<u64>,
    ) -> Result<ProductionInferenceResult, String> {
        self.execute_with_policy(
            prompt,
            max_output_tokens,
            false,
            None,
        )
    }

    pub fn execute_adaptive(
        &self,
        prompt: &str,
        max_output_tokens: Option<u64>,
        absolute_ceiling_ms: Option<u64>,
    ) -> Result<ProductionInferenceResult, String> {
        self.execute_with_policy(
            prompt,
            max_output_tokens,
            true,
            absolute_ceiling_ms,
        )
    }

    fn execute_with_policy(
        &self,
        prompt: &str,
        max_output_tokens: Option<u64>,
        adaptive_execution: bool,
        absolute_ceiling_ms: Option<u64>,
    ) -> Result<ProductionInferenceResult, String> {
        let prompt = prompt.trim();

        if prompt.is_empty() {
            return Err("production_task_prompt_empty".into());
        }
        // ADAPTIVE_GENERATION_BUDGET_V1
        const ADAPTIVE_DEFAULT_OUTPUT_TOKENS_V1: u64 = 4096;

        let requested_u64 =
            max_output_tokens
                .unwrap_or(
                    if adaptive_execution {
                        ADAPTIVE_DEFAULT_OUTPUT_TOKENS_V1
                    } else {
                        512
                    }
                )
                .max(1);

        let requested =
            u32::try_from(requested_u64)
                .unwrap_or(u32::MAX);

        let generation =
            if adaptive_execution {
                production_generation_settings_adaptive_v1(
                    prompt,
                    None,
                    None,
                )
            } else {
                production_generation_settings_v1(
                    prompt,
                    None,
                    Some(requested.min(4096)),
                )
            };

        let request_max_tokens: i64 =
            if adaptive_execution &&
                generation.max_tokens == u32::MAX
            {
                -1
            } else {
                generation.max_tokens
                    .max(1)
                    .min(4096) as i64
            };

        let max_tokens =
            if request_max_tokens < 0 {
                0
            } else {
                request_max_tokens as u32
            };

        println!(
            "INFERENCE_OUTPUT_TOKEN_LIMIT={}",
            if request_max_tokens < 0 {
                "unbounded".to_string()
            } else {
                request_max_tokens.to_string()
            }
        );

        let mut body = json!({
            "model": "local-model",
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": generation.temperature,
            "top_p": generation.top_p,
            "max_tokens": request_max_tokens,
            "stop": generation.stop,
            "stream": false
        });

        // JSON_CONSTRAINED_GENERATION_V1
        // Keep live customer execution aligned with certification:
        // JSON-mode tasks use llama.cpp constrained JSON generation.
        if generation.mode == "json" {
            body["json_schema"] = json!({
                "type": "object"
            });
        }

        let started = Instant::now();

        let response = self
            .http
            .post(format!("{}/v1/chat/completions", self.base_url))
            .header("Authorization", "Bearer no-key")
            .json(&body)
            .timeout(
                inference_request_timeout_v1(
                    adaptive_execution,
                    absolute_ceiling_ms,
                )
            )
            .send()
            .map_err(|error| {
                if error.is_timeout() {
                    "production_llama_timeout".to_string()
                } else {
                    "production_llama_request_failed".to_string()
                }
            })?;

        let status = response.status();

        let raw = response
            .text()
            .map_err(|_| "production_llama_response_read_failed".to_string())?;

        if !status.is_success() {
            let body =
                raw
                    .replace('\r', " ")
                    .replace('\n', " ");

            let body: String =
                body
                    .chars()
                    .take(800)
                    .collect();

            return Err(format!(
                "production_llama_http_{}_body={}",
                status.as_u16(),
                body
            ));
        }let parsed: Value = serde_json::from_str(&raw)
            .map_err(|_| "production_llama_response_invalid".to_string())?;

        let output = parsed
            .pointer("/choices/0/message/content")
            .and_then(Value::as_str)
            .unwrap_or("")
            .trim();

        if output.is_empty() {
            return Err("production_llama_empty_output".into());
        }

        let ai_output = if generation.mode == "json" {
            match serde_json::from_str::<Value>(output) {
                Ok(Value::Object(object)) => serde_json::to_string(&Value::Object(object))
                    .map_err(|_| "production_output_encode_failed".to_string())?,
                Ok(_) => {
                    return Err("production_json_output_not_object".into());
                }
                Err(_) => {
                    return Err("production_json_output_invalid".into());
                }
            }
        } else if output.starts_with('{') {
            match serde_json::from_str::<Value>(output) {
                Ok(Value::Object(object)) => serde_json::to_string(&Value::Object(object))
                    .map_err(|_| "production_output_encode_failed".to_string())?,
                _ => json!({"response": output}).to_string(),
            }
        } else {
            json!({"response": output}).to_string()
        };

        let latency_ms = started.elapsed().as_millis() as u64;

        let input_tokens = parsed
            .pointer("/usage/prompt_tokens")
            .and_then(Value::as_u64)
            .or_else(|| parsed.pointer("/timings/prompt_n").and_then(Value::as_u64))
            .unwrap_or(0);

        let output_tokens = parsed
            .pointer("/usage/completion_tokens")
            .and_then(Value::as_u64)
            .or_else(|| {
                parsed
                    .pointer("/timings/predicted_n")
                    .and_then(Value::as_u64)
            })
            .unwrap_or(0);

        let tokens_per_second = parsed
            .pointer("/timings/predicted_per_second")
            .and_then(Value::as_f64)
            .unwrap_or_else(|| {
                if latency_ms > 0 {
                    output_tokens as f64 / (latency_ms as f64 / 1000.0)
                } else {
                    0.0
                }
            });

        let prompt_eval_ms = parsed
            .pointer("/timings/prompt_ms")
            .and_then(Value::as_f64)
            .map(|value| value.round() as u64);

        let generation_ms = parsed
            .pointer("/timings/predicted_ms")
            .and_then(Value::as_f64)
            .map(|value| value.round() as u64);

        Ok(ProductionInferenceResult {
            ai_output,
            latency_ms,
            input_tokens,
            output_tokens,
            tokens_per_second,
            prompt_eval_ms,
            generation_ms,
            max_tokens,
        })
    }
}
